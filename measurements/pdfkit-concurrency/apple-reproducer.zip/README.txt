PDFKit attributed-text NSFont exception (macOS)

Observed on macOS 27.0 (26A428), Xcode 27.0 (27A266a), arm64.
This is separate from the attributed-text memory leak reported as FB24783799.

The probe uses only public Apple APIs. No third-party dependencies or library sources
are needed for this build. Each worker opens its own PDFDocument from the same fixture
URL on each iteration, extracts all three lines and checks their text and font sizes.
No PDFDocument, PDFPage, PDFSelection or NSAttributedString crosses threads.

Build from this directory with full Xcode selected:
  xcrun swiftc -swift-version 6 -O -parse-as-library probe.swift -o probe

Concurrent attributed extraction (intermittent crash; one invocation can pass):
  ./probe rolemap.pdf attributed 8 1000 > concurrent.stdout.log 2> concurrent.stderr.log

Serial background and plain-text controls, each in a fresh process:
  ./probe rolemap.pdf attributed 1 1000 > serial.stdout.log 2> serial.stderr.log
  ./probe rolemap.pdf plain 8 1000 > plain.stdout.log 2> plain.stderr.log

Worker count 0 tests main-thread extraction. The untagged.pdf control removes the
structure tree but retains identical text/font/content-stream instructions. qpdf finds
no syntax or stream-encoding errors in either fixture; that is not a semantic validation.

Expected: three exact text lines with Helvetica 12/24/24-point fonts on every iteration,
or a recoverable API error; no process termination for independent document extraction.
Observed: uncaught NSInvalidArgumentException / nil NSFont inside PDFSelection's
createAttributedStringForCGSelection:scaled:, terminating the process with SIGABRT.
See sdk-crash.stderr.log for a complete fresh-process failing run.

A five-trial matrix per fixture/mode/worker count yields one abort in ten concurrent
attributed processes, zero in ten serial attributed processes, and zero in twenty
plain-text processes. These small counts do not establish an underlying Apple cause,
a general crash rate, or that structure tags are necessary. No physical iOS reproduction
is claimed. The application library serializes its own extraction as a bounded mitigation;
that cannot coordinate independent PDFKit calls made by the host application.

Probe/fixture code: MIT, PDFReflowLib contributors (see LICENSE).
