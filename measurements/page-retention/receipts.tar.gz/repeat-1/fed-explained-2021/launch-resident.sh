#!/bin/sh
exec '/private/tmp/claude-501/-Users-trevorharmon-Development-PDFReflowLib/37f1536b-72d1-4d8c-ad8b-d20d74ebf757/scratchpad/candidate-pdf-reflow' "$@" '--reference-images' 'automatic'
