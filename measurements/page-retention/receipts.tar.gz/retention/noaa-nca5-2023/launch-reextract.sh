#!/bin/sh
exec '/Users/trevorharmon/Development/PDFReflowLib/.build/out/Products/Release/pdf-reflow' "$@" '--reference-images' 'automatic' '--maximum-output-bytes' '4294967296' '--maximum-epub-bytes' '4294967296'
