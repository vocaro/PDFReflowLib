#!/bin/sh
exec '/Users/trevorharmon/Development/PDFReflowLib/.build/out/Products/Release/pdf-reflow' "$@" '--reference-images' 'automatic'
